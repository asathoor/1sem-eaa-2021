# CSS = Cascading Style Sheets

Her kan du lægge dine stylesheets. Filen `style.css` kan bruges til dine styles. Filen kan bruges af alle dine `.html` filer.
